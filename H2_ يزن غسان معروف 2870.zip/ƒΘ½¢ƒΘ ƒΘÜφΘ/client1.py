import socket


client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(("127.0.0.1", 4444))

while True:
    response = client.recv(4096).decode('utf-8')
    print(response, end='')

    if "Enter username" in response or "Enter password" in response or "Enter amount" in response or "Choose an option" in response:
        message = input().strip()
        client.send(message.encode('utf-8'))

    if "Your final balance" in response:
        break

client.close()
