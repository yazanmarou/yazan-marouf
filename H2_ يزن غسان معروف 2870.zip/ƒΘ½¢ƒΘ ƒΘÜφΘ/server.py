import socket
import threading

# Pre-defined bank accounts
accounts = {
    "yazan": {"password": "pass1", "balance": 1000},
    "user2": {"password": "pass2", "balance": 2000},
}

def handle_client(client_socket):
    try:
        # Authentication
        client_socket.sendall(b"Enter username: ")
        username = client_socket.recv(1024).decode('utf-8')
        client_socket.sendall(b"Enter password: ")
        password = client_socket.recv(1024).decode('utf-8')

        if username in accounts and accounts[username]["password"] == password:
            client_socket.sendall(b"Authentication successful!\n")
        else:
            client_socket.sendall(b"Authentication failed!\n")
            client_socket.close()
            return

        while True:
            client_socket.sendall(b"\nChoose an option: (1) Check balance, (2) Deposit, (3) Withdraw, (4) Exit\n")
            option = client_socket.recv(1024).decode('utf-8').strip()

            if option == '1':
                balance = accounts[username]["balance"]
                client_socket.sendall(f"Your balance is: {balance}\n".encode('utf-8'))
            elif option == '2':
                client_socket.sendall(b"Enter amount to deposit: ")
                amount = int(client_socket.recv(1024).decode('utf-8').strip())
                accounts[username]["balance"] += amount
                client_socket.sendall(b"Deposit successful!\n")
            elif option == '3':
                client_socket.sendall(b"Enter amount to withdraw: ")
                amount = int(client_socket.recv(1024).decode('utf-8').strip())
                if accounts[username]["balance"] >= amount:
                    accounts[username]["balance"] -= amount
                    client_socket.sendall(b"Withdrawal successful!\n")
                else:
                    client_socket.sendall(b"Insufficient funds!\n")
            elif option == '4':
                final_balance = accounts[username]["balance"]
                client_socket.sendall(f"Your final balance is: {final_balance}\n".encode('utf-8'))
                client_socket.close()
                break
            else:
                client_socket.sendall(b"Invalid option. Please try again.\n")
    except Exception as e:
        print(f"Error handling client {client_socket.getpeername()}: {e}")
        client_socket.close()

Host="127.0.0.1"
port=4444
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((Host, port))
server.listen(5)
print(f"Server started. Listening on port {Host}:{port}")

while True:
    client_socket, addr = server.accept()
    print(f"Accepted connection from {addr}")
    client_handler = threading.Thread(target=handle_client, args=(client_socket,))
    client_handler.start()
